Helios by HTML5 UP
html5up.net | @n33co
Free for personal and commercial use under the CCA 3.0 license (html5up.net/license)


This is Helios, a brand new site template for HTML5 UP. It's clean, modern, and designed
to take advantage of larger (well, wider) displays while still being capable of gracefully
scaling down to fit all manner of smaller ones.
	
Demo images* courtesy of Michael Domaradzki, an awesome photographer I met over at
deviantART. Check out his portfolio here:

http://md.photomerchant.net/

(* = Not included! Only meant for use with my own on-site demo, so please do NOT download
and/or use any of Michaels's work without his explicit permission!)

AJ
n33.co @n33co dribbble.com/n33


Credits:

	Demo Images:
		Michael Domaradzki (md.photomerchant.net)
		
	Icons:
		Font Awesome (fortawesome.github.com/Font-Awesome)

	Other:
		jQuery (jquery.com)
		html5shiv.js (@afarkas @jdalton @jon_neal @rem)
		CSS3 Pie (css3pie.com)
		background-size polyfill (github.com/louisremi)
		jquery.dropotron (n33.co)
		jquery.scrolly (n33.co)
		jquery.onvisible (n33.co)
		skel (n33.co)